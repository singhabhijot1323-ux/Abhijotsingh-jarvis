# Jarvis (Android)

Voice assistant for your Android phone. Works offline (voice, commands, small local AI) and online (Claude). Has a built-in endpoint so your ESP32 speaker can use it later.

## Build it
1. Install **Android Studio** on a computer and open this folder (`jarvis`).
2. Let Gradle sync, plug in your phone (USB debugging on), press **Run**.
3. Allow the permissions it asks for (mic, calls, SMS, contacts).

## Offline voice
Install the offline speech pack: Settings > Google > Speech (or Voice) > Offline speech recognition, and download your language.

## Offline AI (optional)
1. Download a Gemma `.task` model (e.g. Gemma 3 1B, int4) from Hugging Face / Kaggle (LiteRT / MediaPipe format).
2. Copy the file to your phone, open Jarvis, tap **Import offline model**, pick it.
3. Needs a phone with roughly 6 GB+ RAM for the 1B model. Gemma-format prompts are used, so stick to Gemma models.

## Online AI (optional)
Paste a Claude API key into the app. Online questions go to Claude; if you are offline or the call fails, the local model answers. The key is stored only on your phone.

## Commands that work with no internet
- "set an alarm for 6:30 am", "wake me up at 7"
- "set a timer for 10 minutes"
- "remind me to drink water in 20 minutes", "remind me to call dad at 5 pm"
- "call mom", "text mom saying I'm late", "whatsapp mom saying hello"
- "open YouTube", "flashlight on/off", "volume up/down/max/mute"
- "wifi", "bluetooth" (opens the system panel; Android blocks apps from toggling them)
Anything else goes to the AI brain.

Notes: WhatsApp opens with the message filled in, you tap send (WhatsApp has no silent send). 10-digit numbers get +91 added.

## ESP32 speaker (later)
The app runs a small server on port 8765 (token shown at the bottom of the app). Keep Jarvis open on the phone, same Wi-Fi as the ESP32.

```
POST http://<phone-ip>:8765/command
X-Token: <token>
body: turn on the flashlight          (or {"text": "..."})
-> {"reply": "Flashlight on"}
```
The ESP32 needs to turn speech into text (e.g. a small offline keyword/ASR module or streaming to a speech service), send the text here, then speak the reply with its own TTS. Audio streaming straight to the phone is a natural next step.

## Known limits (v0.1)
- Tap-to-speak only. Always-listening "Hey Jarvis" needs a wake-word engine (Porcupine / openWakeWord) plus a foreground service; that is the next upgrade.
- The server and actions work while the app is open; Android restricts background app launching.
- Not compiled or tested on a device yet, so expect small fixes on the first build.
