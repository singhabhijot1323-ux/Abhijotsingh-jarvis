package com.jarvis.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * The thinking part. Online with an API key -> Claude. Offline (or if the cloud call fails)
 * -> a small Gemma model running on the phone, if you've imported one.
 */
class Brain(private val ctx: Context) {

    private val prefs = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val history = mutableListOf<Pair<String, String>>() // role to text, cloud only

    @Volatile private var llm: LlmInference? = null
    private val modelFile get() = File(ctx.filesDir, "model.task")

    fun hasLocalModel() = modelFile.exists()
    fun modelPath(): String = modelFile.absolutePath

    fun reload() {
        synchronized(this) { llm?.close(); llm = null }
    }

    fun isOnline(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    suspend fun ask(text: String): String = withContext(Dispatchers.IO) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isNotBlank() && isOnline()) {
            try {
                return@withContext cloud(key, text)
            } catch (e: Exception) {
                // fall through to the offline model
            }
        }
        try {
            local(text)
        } catch (e: Exception) {
            "Sorry, I couldn't answer that: ${e.message}"
        }
    }

    private fun cloud(key: String, text: String): String {
        val msgs = JSONArray()
        history.takeLast(8).forEach { (role, content) ->
            msgs.put(JSONObject().put("role", role).put("content", content))
        }
        msgs.put(JSONObject().put("role", "user").put("content", text))

        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 300)
            .put("system", SYSTEM)
            .put("messages", msgs)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        if (conn.responseCode != 200) {
            val err = conn.errorStream?.bufferedReader()?.readText().orEmpty()
            throw IOException("HTTP ${conn.responseCode}: $err")
        }
        val resp = conn.inputStream.bufferedReader().readText()
        val reply = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text").trim()
        history.add("user" to text)
        history.add("assistant" to reply)
        return reply
    }

    private fun local(text: String): String {
        if (!modelFile.exists()) {
            return "I'm offline and no local model is installed yet. Import one from the settings."
        }
        val engine = llm ?: synchronized(this) {
            llm ?: LlmInference.createFromOptions(
                ctx,
                LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(modelFile.absolutePath)
                    .setMaxTokens(512)
                    .build()
            ).also { llm = it }
        }
        // Gemma chat format
        val prompt = "<start_of_turn>user\n$SYSTEM\n\n$text<end_of_turn>\n<start_of_turn>model\n"
        return engine.generateResponse(prompt).trim()
    }

    companion object {
        const val SYSTEM =
            "You are Jarvis, a concise voice assistant on the user's phone. " +
                "Reply in one to three short spoken sentences. No markdown, no lists."
    }
}
