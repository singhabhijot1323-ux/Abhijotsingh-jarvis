package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {

    private lateinit var jarvis: Jarvis
    private lateinit var voice: Voice
    private var server: BridgeServer? = null

    private val log = mutableStateListOf<String>()
    private var status by mutableStateOf("")
    private var token by mutableStateOf("")

    private val prefs get() = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    private val permissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private val importModel =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importModelFrom(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        jarvis = Jarvis(applicationContext)
        voice = Voice(this, onText = { submit(it) }, onError = { log.add("Jarvis: $it") })

        permissions.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS
            )
        )

        token = prefs.getString("token", null) ?: UUID.randomUUID().toString().take(12).also {
            prefs.edit().putString("token", it).apply()
        }
        startBridge()
        refreshStatus()

        setContent { MaterialTheme { Screen() } }
    }

    override fun onDestroy() {
        server?.stop()
        voice.shutdown()
        super.onDestroy()
    }

    private fun startBridge() {
        try {
            server = BridgeServer(PORT, token) { text ->
                runBlocking { jarvis.handle(text) }
            }.also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
        } catch (e: Exception) {
            log.add("Jarvis: ESP32 bridge couldn't start (${e.message})")
        }
    }

    private fun refreshStatus() {
        val net = if (jarvis.brain.isOnline()) "Online" else "Offline"
        val model = if (jarvis.brain.hasLocalModel()) "local model ready" else "no local model"
        val key = if (prefs.getString("api_key", "").isNullOrBlank()) "no API key" else "cloud AI on"
        status = "$net  |  $model  |  $key"
    }

    private fun submit(text: String) {
        log.add("You: $text")
        lifecycleScope.launch {
            val reply = withContext(Dispatchers.Default) { jarvis.handle(text) }
            log.add("Jarvis: $reply")
            voice.speak(reply)
            refreshStatus()
        }
    }

    private fun importModelFrom(uri: Uri) {
        lifecycleScope.launch {
            log.add("Jarvis: importing model, this can take a minute...")
            try {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)!!.use { input ->
                        File(filesDir, "model.task").outputStream().use { input.copyTo(it) }
                    }
                }
                jarvis.brain.reload()
                log.add("Jarvis: offline model imported")
            } catch (e: Exception) {
                log.add("Jarvis: import failed (${e.message})")
            }
            refreshStatus()
        }
    }

    @Composable
    private fun Screen() {
        var input by remember { mutableStateOf("") }
        var apiKey by remember { mutableStateOf(prefs.getString("api_key", "").orEmpty()) }
        val listState = rememberLazyListState()
        LaunchedEffect(log.size) { if (log.isNotEmpty()) listState.animateScrollToItem(log.size - 1) }

        Column(
            Modifier.fillMaxSize().padding(16.dp).padding(top = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("JARVIS", style = MaterialTheme.typography.headlineMedium)
            Text(status, style = MaterialTheme.typography.bodySmall)

            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
                items(log) { Text(it, Modifier.padding(vertical = 4.dp)) }
            }

            Button(onClick = { voice.listen() }, Modifier.fillMaxWidth()) { Text("Speak") }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    input, { input = it }, Modifier.weight(1f),
                    placeholder = { Text("or type a command") }, singleLine = true
                )
                Button(onClick = { if (input.isNotBlank()) { submit(input); input = "" } }) { Text("Send") }
            }

            OutlinedTextField(
                apiKey,
                { apiKey = it; prefs.edit().putString("api_key", it.trim()).apply(); refreshStatus() },
                Modifier.fillMaxWidth(),
                label = { Text("Claude API key (optional, for online AI)") },
                singleLine = true
            )
            OutlinedButton(onClick = { importModel.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) {
                Text("Import offline model (.task)")
            }
            Text("ESP32 bridge: port $PORT   token: $token", style = MaterialTheme.typography.bodySmall)
        }
    }

    companion object {
        const val PORT = 8765
    }
}
