package com.jarvis.assistant

import android.content.Context

/** One entry point used by the phone UI and the ESP32 bridge: commands first, AI second. */
class Jarvis(ctx: Context) {
    val actions = PhoneActions(ctx)
    val router = CommandRouter(actions)
    val brain = Brain(ctx)

    suspend fun handle(text: String): String {
        val clean = text.trim()
        if (clean.isEmpty()) return "I didn't hear anything"
        return try {
            router.route(clean) ?: brain.ask(clean)
        } catch (e: Exception) {
            "That didn't work: ${e.message}"
        }
    }
}
