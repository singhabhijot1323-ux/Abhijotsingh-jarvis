package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

/** Everything Jarvis can physically do on the phone. Each function returns a spoken reply. */
class PhoneActions(private val ctx: Context) {

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    // ---------- alarms, timers, reminders ----------

    fun setAlarm(hour: Int, minute: Int, label: String? = null): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label != null) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        start(i)
        return "Alarm set for %d:%02d".format(hour, minute) + (label?.let { " to $it" } ?: "")
    }

    fun setTimer(seconds: Int, label: String? = null): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceIn(1, 86400))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label != null) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        start(i)
        return "Timer set for " + spoken(seconds) + (label?.let { " to $it" } ?: "")
    }

    private fun spoken(s: Int): String = when {
        s % 3600 == 0 -> "${s / 3600} hour" + if (s / 3600 > 1) "s" else ""
        s % 60 == 0 -> "${s / 60} minute" + if (s / 60 > 1) "s" else ""
        else -> "$s seconds"
    }

    // ---------- contacts, calls, messages ----------

    private fun lookupNumber(nameOrNumber: String): String? {
        val digits = nameOrNumber.replace(Regex("[\\s-]"), "")
        if (digits.matches(Regex("\\+?\\d{6,15}"))) return digits
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$nameOrNumber%"),
            null
        )
        c?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    fun call(who: String): String {
        val number = lookupNumber(who) ?: return "I couldn't find $who in your contacts"
        val uri = Uri.parse("tel:" + Uri.encode(number))
        return if (has(Manifest.permission.CALL_PHONE)) {
            start(Intent(Intent.ACTION_CALL, uri)); "Calling $who"
        } else {
            start(Intent(Intent.ACTION_DIAL, uri)); "Opening the dialer for $who"
        }
    }

    fun sms(who: String, body: String): String {
        val number = lookupNumber(who) ?: return "I couldn't find $who in your contacts"
        if (!has(Manifest.permission.SEND_SMS)) return "I need SMS permission first"
        val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()
        sm.sendMultipartTextMessage(number, null, sm.divideMessage(body), null, null)
        return "Message sent to $who"
    }

    fun whatsapp(who: String, body: String): String {
        val raw = lookupNumber(who) ?: return "I couldn't find $who in your contacts"
        var n = raw.filter { it.isDigit() }
        if (n.length == 10) n = "91$n" // default to India country code
        start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=${Uri.encode(body)}")))
        return "WhatsApp is open with your message to $who. Tap send."
    }

    // ---------- apps and phone controls ----------

    fun openApp(name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return "I couldn't find an app called $name"
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "I couldn't open $name"
        start(launch)
        return "Opening ${hit.loadLabel(pm)}"
    }

    fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "This phone has no flashlight"
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on" else "Flashlight off"
    }

    fun volume(action: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val s = AudioManager.STREAM_MUSIC
        val f = AudioManager.FLAG_SHOW_UI
        when (action) {
            "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, f)
            "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, f)
            "max" -> am.setStreamVolume(s, am.getStreamMaxVolume(s), f)
            "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, f)
        }
        return "Volume $action"
    }

    /** Android no longer lets apps toggle Wi-Fi/Bluetooth directly, so we open the system panel. */
    fun wifiPanel(): String {
        val action = if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
        else Settings.ACTION_WIFI_SETTINGS
        start(Intent(action)); return "Here are your Wi-Fi settings"
    }

    fun bluetoothPanel(): String {
        start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Here are your Bluetooth settings"
    }
}
