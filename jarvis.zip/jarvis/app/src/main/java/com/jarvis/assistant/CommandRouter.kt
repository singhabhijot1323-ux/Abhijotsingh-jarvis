package com.jarvis.assistant

/**
 * Offline command understanding: plain pattern matching, instant and works with no internet.
 * Returns the spoken reply, or null if the sentence isn't a known command (then the AI brain answers).
 */
class CommandRouter(private val a: PhoneActions) {

    private val unit = "(second|sec|minute|min|hour|hr)"
    private val timeRx = Regex("""(\d{1,2})(?:[:.](\d{2}))?\s*(a\.?\s?m\.?|p\.?\s?m\.?)?""")

    private fun seconds(n: Int, u: String) = when {
        u.startsWith("h") -> n * 3600
        u.startsWith("m") -> n * 60
        else -> n
    }

    private fun parseTime(s: String): Pair<Int, Int>? {
        val m = timeRx.find(s) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val ap = m.groupValues[3].lowercase()
        if (ap.startsWith("p") && h < 12) h += 12
        if (ap.startsWith("a") && h == 12) h = 0
        return if (h in 0..23 && min in 0..59) h to min else null
    }

    fun route(raw: String): String? {
        val t = raw.lowercase().trim().removePrefix("jarvis").trim(',', ' ', '.', '!', '?')
        if (t.isEmpty()) return null

        // reminders: "remind me to drink water in 10 minutes" / "remind me to call dad at 5 pm"
        Regex("^remind me (?:to )?(.+?) in (\\d+)\\s*$unit" + "s?$").find(t)?.let {
            return a.setTimer(seconds(it.groupValues[2].toInt(), it.groupValues[3]), it.groupValues[1])
        }
        Regex("^remind me (?:to )?(.+?) at (.+)$").find(t)?.let {
            val tm = parseTime(it.groupValues[2]) ?: return null
            return a.setAlarm(tm.first, tm.second, it.groupValues[1])
        }

        // timers
        if ("timer" in t) {
            Regex("(\\d+)\\s*$unit").find(t)?.let {
                return a.setTimer(seconds(it.groupValues[1].toInt(), it.groupValues[2]))
            }
        }

        // alarms: "set an alarm for 6:30 am", "wake me up at 7"
        Regex("(?:alarm|wake me up|wake me).*?(?:for|at)\\s+(.+)$").find(t)?.let {
            val tm = parseTime(it.groupValues[1])
            if (tm != null) return a.setAlarm(tm.first, tm.second)
        }

        // messages
        Regex("^(?:send (?:a )?)?whatsapp (?:message )?(?:to )?(.+?) (?:saying|that|with|message) (.+)$").find(t)?.let {
            return a.whatsapp(it.groupValues[1], it.groupValues[2])
        }
        Regex("^(?:text|sms|message|send (?:a )?(?:text|sms|message) to) (.+?) (?:saying|that|with) (.+)$").find(t)?.let {
            return a.sms(it.groupValues[1], it.groupValues[2])
        }

        // calls
        Regex("^(?:call|phone|dial|ring) (.+)$").find(t)?.let { return a.call(it.groupValues[1]) }

        // flashlight
        if ("flashlight" in t || "torch" in t) return a.torch(on = "off" !in t)

        // volume
        if ("volume" in t || "louder" in t || "quieter" in t) {
            return when {
                "mute" in t -> a.volume("mute")
                "max" in t || "full" in t -> a.volume("max")
                "down" in t || "lower" in t || "decrease" in t || "quieter" in t -> a.volume("down")
                else -> a.volume("up")
            }
        }

        // connectivity panels
        if (Regex("wi-?\\s?fi").containsMatchIn(t)) return a.wifiPanel()
        if ("bluetooth" in t) return a.bluetoothPanel()

        // open apps
        Regex("^(?:open|launch|start) (.+)$").find(t)?.let { return a.openApp(it.groupValues[1]) }

        return null
    }
}
