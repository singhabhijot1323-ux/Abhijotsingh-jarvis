package com.jarvis.assistant

import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject

/**
 * Local HTTP endpoint for your future ESP32 speaker (same Wi-Fi as the phone).
 *
 *   POST /command   header  X-Token: <token shown in the app>
 *                   body    plain text, or {"text":"..."}
 *   ->  {"reply":"..."}
 *
 *   GET /ping       -> {"ok":true}
 */
class BridgeServer(
    port: Int,
    private val token: String,
    private val handler: (String) -> String
) : NanoHTTPD(port) {

    private fun json(status: Response.Status, body: JSONObject) =
        newFixedLengthResponse(status, "application/json", body.toString())

    override fun serve(session: IHTTPSession): Response {
        if (session.uri == "/ping") return json(Response.Status.OK, JSONObject().put("ok", true))

        if (session.uri != "/command" || session.method != Method.POST) {
            return json(Response.Status.NOT_FOUND, JSONObject().put("error", "not found"))
        }
        if (session.headers["x-token"] != token) {
            return json(Response.Status.UNAUTHORIZED, JSONObject().put("error", "bad token"))
        }
        return try {
            val files = HashMap<String, String>()
            session.parseBody(files)
            val raw = files["postData"].orEmpty().trim()
            val text = if (raw.startsWith("{")) JSONObject(raw).optString("text") else raw
            json(Response.Status.OK, JSONObject().put("reply", handler(text)))
        } catch (e: Exception) {
            json(Response.Status.INTERNAL_ERROR, JSONObject().put("error", e.message ?: "error"))
        }
    }
}
