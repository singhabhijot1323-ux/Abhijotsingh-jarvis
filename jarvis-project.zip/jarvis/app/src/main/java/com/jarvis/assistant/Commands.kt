package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/** Offline phone commands. Returns a spoken reply, or null if the text isn't a known command. */
object Commands {

    fun run(ctx: Context, raw: String): String? {
        val t = raw.lowercase(Locale.ROOT).trim().trimEnd('.', '!', '?', ',')
        return dispatch(ctx, t)
    }

    private fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun dispatch(ctx: Context, t: String): String? {
        // Small talk that works offline
        if (Regex("^(hello|hi|hey)( there)?$").matches(t)) return "Hello. How can I help?"
        if (Regex("who are you|what is your name|what's your name").containsMatchIn(t)) return "I'm Jarvis, your phone assistant."
        if (Regex("^(thanks|thank you)").containsMatchIn(t)) return "Anytime."

        // Time and date
        if (Regex("what('s| is) the time|what time is it|^time$|tell me the time").containsMatchIn(t))
            return "It's " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        if (Regex("(what('s| is)|tell me) (the |today's )?date|what day is (it|today)").containsMatchIn(t))
            return "Today is " + SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())

        // Battery
        if (Regex("battery (level|percentage|percent|status|left)|how much battery|^battery$").containsMatchIn(t)) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            return "Battery is at ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent."
        }

        // Flashlight
        if (Regex("flash ?light|torch").containsMatchIn(t)) {
            val on = !Regex("\\boff\\b|turn off|disable").containsMatchIn(t)
            setTorch(ctx, on)
            return if (on) "Flashlight on." else "Flashlight off."
        }

        // Volume
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Regex("volume up|louder|increase (the )?volume|turn it up").containsMatchIn(t)) {
            repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
            return "Volume up."
        }
        if (Regex("volume down|quieter|lower (the )?volume|decrease (the )?volume|turn it down").containsMatchIn(t)) {
            repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
            return "Volume down."
        }
        if (Regex("^mute( the)?( phone| volume)?$").matches(t)) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            return "Muted."
        }

        // Alarm
        if (t.contains("alarm") || Regex("wake me( up)?").containsMatchIn(t)) {
            val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(t)
                ?: return "What time should I set the alarm for?"
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3]
            if (ap.startsWith("p") && h < 12) h += 12
            if (ap.startsWith("a") && h == 12) h = 0
            if (h > 23 || min > 59) return "That time doesn't look right."
            launch(
                ctx,
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, min)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            return String.format(Locale.getDefault(), "Alarm set for %d:%02d.", h, min)
        }

        // Timer
        if (t.contains("timer")) {
            val m = Regex("(\\d+)\\s*(hour|hr|minute|min|second|sec)").find(t)
                ?: return "How long should the timer be?"
            val n = m.groupValues[1].toInt()
            val unit = m.groupValues[2]
            val secs = when {
                unit.startsWith("h") -> n * 3600
                unit.startsWith("m") -> n * 60
                else -> n
            }
            launch(
                ctx,
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            return "Timer set for $n $unit${if (n == 1) "" else "s"}."
        }

        // Wi-Fi / Bluetooth: Android doesn't let apps toggle these, so open the screen.
        if (Regex("wi-?fi").containsMatchIn(t) && Regex("setting|turn|switch|connect").containsMatchIn(t)) {
            launch(ctx, Intent(Settings.ACTION_WIFI_SETTINGS))
            return "Android doesn't let apps toggle Wi-Fi, so I opened the Wi-Fi screen."
        }
        if (t.contains("bluetooth") && Regex("setting|turn|switch|connect").containsMatchIn(t)) {
            launch(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return "Android doesn't let apps toggle Bluetooth, so I opened the Bluetooth screen."
        }

        // Speaker (ESP32)
        Regex("^(?:tell the speaker|speaker say|say on the speaker|say on speaker) (.+)$").find(t)?.let {
            return sendToSpeaker(ctx, it.groupValues[1])
        }

        // YouTube / search / maps
        Regex("^play (.+) on youtube$").find(t)?.let {
            val q = URLEncoder.encode(it.groupValues[1], "UTF-8")
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q")))
            return "Searching YouTube for ${it.groupValues[1]}."
        }
        Regex("^(?:navigate to|directions to|take me to) (.+)$").find(t)?.let {
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(it.groupValues[1]))))
            return "Starting navigation to ${it.groupValues[1]}."
        }
        Regex("^(?:search|google|look up)(?: for)? (.+)$").find(t)?.let {
            val q = URLEncoder.encode(it.groupValues[1], "UTF-8")
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")))
            return "Searching for ${it.groupValues[1]}."
        }

        // Calls
        Regex("^(?:call|dial|phone) (.+)$").find(t)?.let { return call(ctx, it.groupValues[1].trim()) }

        // Open an app (keep last among "open ..." commands)
        Regex("^(?:open|launch|start) (.+)$").find(t)?.let { return openApp(ctx, it.groupValues[1].trim()) }

        return null
    }

    private fun setTorch(ctx: Context, on: Boolean) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: throw IllegalStateException("this phone has no flashlight")
        cm.setTorchMode(id, on)
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val target = apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT) == name }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(name) }
            ?: return "I couldn't find an app called $name."
        val intent = pm.getLaunchIntentForPackage(target.activityInfo.packageName)
            ?: return "I couldn't open $name."
        launch(ctx, intent)
        return "Opening ${target.loadLabel(pm)}."
    }

    private fun call(ctx: Context, target: String): String {
        val number: String
        if (target.any { it.isLetter() }) {
            number = findNumber(ctx, target)
                ?: return "I couldn't find $target in your contacts, or contacts permission is off."
        } else {
            number = target.filter { it.isDigit() || it == '+' }
            if (number.length < 3) return "That doesn't look like a phone number."
        }
        val canCall = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val action = if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL
        launch(ctx, Intent(action, Uri.parse("tel:" + Uri.encode(number))))
        return if (canCall) "Calling $target." else "Opening the dialer for $target."
    }

    private fun findNumber(ctx: Context, name: String): String? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val phone = ContactsContract.CommonDataKinds.Phone.NUMBER
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(phone),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return null
    }

    private fun sendToSpeaker(ctx: Context, msg: String): String {
        val ip = Prefs.espIp(ctx)
        if (ip.isBlank()) return "Set your ESP32 speaker address in the app first."
        thread {
            try {
                val url = URL("http://$ip/say?text=" + URLEncoder.encode(msg, "UTF-8"))
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 3000
                c.readTimeout = 3000
                c.responseCode
                c.disconnect()
            } catch (_: Exception) {
            }
        }
        return "Sent to your speaker."
    }
}
