package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {

    private val reqCode = 7
    private var pending: (() -> Unit)? = null
    private lateinit var log: TextView

    private val bg = Color.parseColor("#0B1220")
    private val accent = Color.parseColor("#22D3EE")
    private val dim = Color.parseColor("#94A3B8")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun edit(hint: String, value: String = "") = EditText(this).apply {
        this.hint = hint
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(dim)
        setSingleLine(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(col)
        }
        setContentView(scroll)

        col.addView(label("JARVIS", 28f, accent, true))
        col.addView(label("Offline phone commands. Online chat when connected.", 13f, dim))

        col.addView(button("Start always-listening (say \"Jarvis ...\")") {
            ensurePerms {
                startForegroundService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_ALWAYS))
            }
        })
        col.addView(button("Tap to talk (one command)") {
            ensurePerms {
                startForegroundService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_TALK))
            }
        })
        col.addView(button("Stop Jarvis") {
            stopService(Intent(this, JarvisService::class.java))
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
        })

        col.addView(label("Type a command", 14f, accent, true))
        val cmd = edit("e.g. open youtube, set alarm for 7:30 am")
        col.addView(cmd)
        col.addView(button("Send") {
            val text = cmd.text.toString().trim()
            if (text.isNotEmpty()) {
                ensurePerms {
                    startForegroundService(
                        Intent(this, JarvisService::class.java)
                            .setAction(JarvisService.ACTION_TEXT)
                            .putExtra(JarvisService.EXTRA_TEXT, text)
                    )
                }
                cmd.setText("")
            }
        })

        col.addView(label("Conversation", 14f, accent, true))
        log = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            minHeight = dp(160)
            text = "Nothing yet."
        }
        col.addView(log)

        col.addView(label("Online brain (optional)", 14f, accent, true))
        val key = edit(
            if (Prefs.apiKey(this).isEmpty()) "Anthropic API key (sk-ant-...)" else "Key saved. Paste a new one to replace."
        )
        col.addView(key)
        col.addView(button("Save API key") {
            val k = key.text.toString().trim()
            if (k.isNotEmpty()) {
                Prefs.setApiKey(this, k)
                key.setText("")
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            }
        })

        col.addView(label("ESP32 speaker (later)", 14f, accent, true))
        val esp = edit("ESP32 address, e.g. 192.168.1.50", Prefs.espIp(this))
        col.addView(esp)
        col.addView(button("Save ESP32 address") {
            Prefs.setEspIp(this, esp.text.toString())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        col.addView(
            label(
                "Your ESP32 can reach this phone at:\nhttp://${localIp()}:8765/command?t=${Prefs.token(this)}&text=hello",
                12f, dim
            )
        )

        col.addView(label("Make it reliable on vivo", 14f, accent, true))
        col.addView(
            label(
                "1) Allow \"display over other apps\" so Jarvis can open apps while the screen is on.\n" +
                    "2) In app info: enable Autostart, set Battery to \"Allow high background power consumption\", " +
                    "and allow \"Display pop-ups while running in the background\".\n" +
                    "3) Google app > Settings > Voice > Offline speech recognition: download your language.",
                12f, dim
            )
        )
        col.addView(button("Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("Open Jarvis app settings") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
    }

    override fun onResume() {
        super.onResume()
        Bus.onLine = { s ->
            val old = if (log.text.toString() == "Nothing yet.") "" else log.text.toString()
            log.text = (s + "\n" + old).take(3000)
        }
    }

    override fun onPause() {
        Bus.onLine = null
        super.onPause()
    }

    private fun ensurePerms(then: () -> Unit) {
        val wanted = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) {
            then()
        } else {
            pending = then
            requestPermissions(need.toTypedArray(), reqCode)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqCode) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                pending?.invoke()
            } else {
                Toast.makeText(this, "Microphone permission is required", Toast.LENGTH_LONG).show()
            }
            pending = null
        }
    }

    private fun localIp(): String = try {
        val addrs = NetworkInterface.getNetworkInterfaces().toList()
            .sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }
        addrs.firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress ?: "unknown"
    } catch (e: Exception) {
        "unknown"
    }
}
