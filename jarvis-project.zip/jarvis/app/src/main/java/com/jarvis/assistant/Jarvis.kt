package com.jarvis.assistant

import android.content.Context
import kotlin.concurrent.thread

/**
 * The brain. Order of attempts:
 *  1. Offline phone commands (always work, no internet).
 *  2. Online chat (only if online and an API key is saved).
 */
class Jarvis(private val ctx: Context) {
    private val history = ArrayList<Pair<String, String>>()

    fun handle(input: String, onReply: (String) -> Unit) {
        val text = input.trim()
        if (text.isEmpty()) {
            onReply("I didn't catch that.")
            return
        }

        val local = try {
            Commands.run(ctx, text)
        } catch (e: Exception) {
            "That command failed: ${e.message}"
        }
        if (local != null) {
            onReply(local)
            return
        }

        if (!Net.isOnline(ctx)) {
            onReply("I'm offline, so I can only run phone commands right now.")
            return
        }
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) {
            onReply("I only know phone commands so far. Add an API key in the app so I can chat.")
            return
        }

        thread {
            val snapshot = synchronized(history) { history.toList() }
            val result = runCatching { Claude.ask(key, snapshot, text) }
            result.onSuccess { reply ->
                synchronized(history) {
                    history.add("user" to text)
                    history.add("assistant" to reply)
                    while (history.size > 12) {
                        history.removeAt(0)
                        history.removeAt(0)
                    }
                }
                onReply(reply)
            }.onFailure {
                onReply("Sorry, I couldn't reach my online brain.")
            }
        }
    }
}
