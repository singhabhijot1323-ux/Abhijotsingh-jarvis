package com.jarvis.assistant

import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Tiny HTTP server so your ESP32 speaker (or anything on your Wi-Fi) can talk to Jarvis:
 *   GET /ping
 *   GET /command?t=<token>&text=<url-encoded text>   -> plain-text reply
 */
class BridgeServer(
    private val ctx: Context,
    private val jarvis: Jarvis,
    private val log: (String) -> Unit,
    private val port: Int = 8765
) {
    @Volatile
    private var server: ServerSocket? = null

    fun start() {
        if (server != null) return
        thread(isDaemon = true) {
            try {
                val s = ServerSocket(port)
                server = s
                while (!s.isClosed) {
                    val c = s.accept()
                    thread(isDaemon = true) { handle(c) }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun stop() {
        try {
            server?.close()
        } catch (_: Exception) {
        }
        server = null
    }

    private fun handle(c: Socket) {
        c.use { sock ->
            sock.soTimeout = 5000
            val reader = BufferedReader(InputStreamReader(sock.getInputStream()))
            val out = sock.getOutputStream()

            fun send(code: Int, body: String) {
                val bytes = body.toByteArray(Charsets.UTF_8)
                val head = "HTTP/1.1 $code OK\r\nContent-Type: text/plain; charset=utf-8\r\n" +
                    "Content-Length: ${bytes.size}\r\nConnection: close\r\n\r\n"
                out.write(head.toByteArray(Charsets.UTF_8))
                out.write(bytes)
                out.flush()
            }

            val line = reader.readLine() ?: return
            val path = line.split(" ").getOrNull(1) ?: return
            val uri = Uri.parse(path)

            when (uri.path) {
                "/ping" -> send(200, "jarvis ok")
                "/command" -> {
                    if (uri.getQueryParameter("t") != Prefs.token(ctx)) {
                        send(403, "bad token")
                        return
                    }
                    val text = uri.getQueryParameter("text").orEmpty()
                    log("ESP32: $text")
                    var reply = "No reply."
                    val latch = CountDownLatch(1)
                    jarvis.handle(text) {
                        reply = it
                        latch.countDown()
                    }
                    latch.await(25, TimeUnit.SECONDS)
                    log("Jarvis (to ESP32): $reply")
                    send(200, reply)
                }
                else -> send(404, "not found")
            }
        }
    }
}
