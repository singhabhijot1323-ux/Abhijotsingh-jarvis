package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.ServiceCompat
import java.util.Locale

/** Passes log lines from the service to the screen. */
object Bus {
    @Volatile
    var onLine: ((String) -> Unit)? = null

    fun post(s: String) {
        val cb = onLine ?: return
        Handler(Looper.getMainLooper()).post { cb(s) }
    }
}

class JarvisService : Service() {

    companion object {
        const val ACTION_ALWAYS = "com.jarvis.assistant.ALWAYS"
        const val ACTION_TALK = "com.jarvis.assistant.TALK"
        const val ACTION_TEXT = "com.jarvis.assistant.TEXT"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL = "jarvis"
        private val WAKE = Regex("\\b(jarvis|travis|jarvish|jervis)\\b")
        private val LANGUAGE = Locale("en", "IN") // change to Locale.US etc. if you prefer
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var jarvis: Jarvis
    private var bridge: BridgeServer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var always = false
    private var talkOnce = false
    private var speaking = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        jarvis = Jarvis(applicationContext)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is active")
            .setContentText("Say \"Jarvis\" and then a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = LANGUAGE
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        main.post {
                            speaking = false
                            if (always) listen()
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        onDone(utteranceId)
                    }
                })
                ttsReady = true
            }
        }

        bridge = BridgeServer(applicationContext, jarvis, { Bus.post(it) }).also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ALWAYS -> {
                always = true
                Bus.post("Listening. Say \"Jarvis\" and then your command.")
                listen()
            }
            ACTION_TALK -> {
                talkOnce = true
                Bus.post("Listening...")
                listen()
            }
            ACTION_TEXT -> {
                val text = intent.getStringExtra(EXTRA_TEXT).orEmpty()
                Bus.post("You: $text")
                run(text)
            }
        }
        return START_STICKY
    }

    private fun run(cmd: String) {
        jarvis.handle(cmd) { reply -> say(reply) }
    }

    private fun say(text: String) {
        main.post {
            Bus.post("Jarvis: $text")
            if (ttsReady) {
                speaking = true
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
            } else if (always) {
                listen()
            }
        }
    }

    private fun listen() {
        if (speaking) return // onDone restarts listening in always-on mode
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.post("Speech recognition isn't available. Install or update the Google app.")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        recognizer = r
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANGUAGE.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        r.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                Bus.post("Microphone permission is missing.")
                always = false
                talkOnce = false
                return
            }
            if (always) {
                val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L
                main.postDelayed({ listen() }, delay)
            } else if (talkOnce) {
                talkOnce = false
                Bus.post("I didn't catch that.")
            }
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            val needWake = always && !talkOnce
            talkOnce = false
            if (text.isNullOrBlank()) {
                if (always) listen()
                return
            }
            var cmd = text.trim()
            if (needWake) {
                val m = WAKE.find(cmd.lowercase(Locale.ROOT))
                if (m == null) {
                    listen()
                    return
                }
                cmd = cmd.substring(m.range.last + 1).trim().trimStart(',', '.', ' ')
                if (cmd.isEmpty()) {
                    say("Yes?")
                    return
                }
            }
            Bus.post("You: $cmd")
            run(cmd)
        }
    }

    override fun onDestroy() {
        always = false
        recognizer?.destroy()
        tts?.shutdown()
        bridge?.stop()
        super.onDestroy()
    }
}
