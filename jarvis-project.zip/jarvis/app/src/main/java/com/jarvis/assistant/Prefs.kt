package com.jarvis.assistant

import android.content.Context
import java.util.UUID

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = p(c).getString("api_key", "") ?: ""
    fun setApiKey(c: Context, v: String) = p(c).edit().putString("api_key", v.trim()).apply()

    fun espIp(c: Context): String = p(c).getString("esp_ip", "") ?: ""
    fun setEspIp(c: Context, v: String) = p(c).edit().putString("esp_ip", v.trim()).apply()

    /** Shared secret the ESP32 must send so random devices on your Wi-Fi can't control the phone. */
    fun token(c: Context): String {
        var t = p(c).getString("token", null)
        if (t == null) {
            t = UUID.randomUUID().toString().take(8)
            p(c).edit().putString("token", t).apply()
        }
        return t
    }
}
