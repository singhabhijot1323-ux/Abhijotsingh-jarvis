package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Online brain. Only used when the phone is online and an API key is saved. */
object Claude {
    private const val MODEL = "claude-haiku-5-5"
    private const val SYSTEM =
        "You are Jarvis, a concise voice assistant running on the user's phone. " +
            "Reply in one or two short spoken sentences. No markdown, no lists, no emojis."

    fun ask(key: String, history: List<Pair<String, String>>, text: String): String {
        val msgs = JSONArray()
        for ((role, content) in history) {
            msgs.put(JSONObject().put("role", role).put("content", content))
        }
        msgs.put(JSONObject().put("role", "user").put("content", text))

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 300)
            .put("system", SYSTEM)
            .put("messages", msgs)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 30_000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code: $raw")

            val content = JSONObject(raw).getJSONArray("content")
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") return block.getString("text").trim()
            }
            throw IllegalStateException("No text in response")
        } finally {
            conn.disconnect()
        }
    }
}
