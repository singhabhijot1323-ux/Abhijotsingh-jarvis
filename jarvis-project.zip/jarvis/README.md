# Jarvis (Android)

Offline phone commands + online chat + ESP32 bridge.

## Build the APK
- GitHub: push this folder to a repo's main branch, open Actions > Build APK > run, download `jarvis-apk` > app-debug.apk, install it.
- Android Studio: open this folder, Build > Build APK(s).

## Commands (offline)
time, date, battery level, flashlight on/off, volume up/down, mute, set alarm for 7:30 am,
set a timer for 5 minutes, open <app>, call <contact or number>, play <x> on youtube,
search <x>, navigate to <place>, wifi/bluetooth settings, tell the speaker <text>.
Anything else goes to the online brain if you're connected and saved an API key.

## ESP32 bridge
Phone listens on port 8765 (shown in the app with your token):
GET http://<phone-ip>:8765/command?t=<token>&text=<url-encoded text> -> plain-text reply.
